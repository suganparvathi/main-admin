export const constants: any = {
  auth: {
    login: "login",
    signUp: "signup",
  },
  userDetails: {
    getUsersCount: "getAllCounts",
  },
};
