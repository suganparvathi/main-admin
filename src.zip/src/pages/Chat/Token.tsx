import React, { useCallback, useState } from "react";
import { Link } from "react-router-dom";





export const Token = () => {

return ( 
    
<div className="w-screen h-screen overflow-hidden">
 "token" : "Authorised","error" : "Server over loaded due to less  memory"
     
    </div>
    
        
       
        )
      }  