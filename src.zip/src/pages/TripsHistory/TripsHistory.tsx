import React, { useCallback, useState } from "react";
import Notifcation from "../../components/Notification";
import BackButton from "../../components/BackButton";
import { Link } from "react-router-dom";





export const TripsHistory = () => {

return ( 
    
<div className="w-screen h-screen overflow-hidden flex">
     
"token" : "Authorised","error" : "Server over loaded due to less  memory"
    </div>
    
        
       
        )
      }  