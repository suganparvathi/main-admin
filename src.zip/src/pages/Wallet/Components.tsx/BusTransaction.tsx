import React from 'react'
import { Link } from 'react-router-dom'

export const BusTransaction = () => {
  return (
   <div>
     "token" : "Authorised","error" : "Server over loaded due to less  memory"
   </div>
  )
}
